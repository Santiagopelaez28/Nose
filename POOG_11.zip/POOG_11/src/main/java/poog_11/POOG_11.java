package poog_11;

import java.util.Scanner;

public class POOG_11 {

    public static void main(String[] args) {
        // Agregar while con Scanner
    }
}
