package poog_11;

public class Main {

    public static void main(String[] args) {
        Alumno alu1 = new Alumno();
        Alumno alu2 = new Alumno(1,"Pablo","Diaz");

        System.out.println("El id del alumno 2 es: "+ alu2.getId());
        System.out.println("El nombre del alumno 2 es: "+ alu2.getNombre());
        System.out.println("El apellido del alumno 2 es: "+ alu2.getApellido());

        alu1.setId(8);
        alu1.setNombre("Clase de POO");
        alu1.setApellido("Saludos");

        System.out.println("-------------------------------------------------");
        System.out.println("El id del alumno 1 es: "+ alu1.getId());
        System.out.println("El nombre del alumno 1 es: "+ alu1.getNombre());
        System.out.println("El apellido del alumno 1 es: "+ alu1.getApellido());

        System.out.println("-------------------------------------------------");
        alu2.setId(35);
        alu2.setNombre("Juan");
        alu2.setApellido("Perez");
        System.out.println("El id del alumno 2 es: "+ alu2.getId());
        System.out.println("El nombre del alumno 2 es: "+ alu2.getNombre());
        System.out.println("El apellido del alumno 2 es: "+ alu2.getApellido());
    }
}
