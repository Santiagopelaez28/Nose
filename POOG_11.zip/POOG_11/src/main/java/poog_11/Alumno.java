package poog_11;

public class Alumno {

    int id;
    String nombre;
    String apellido;

    public Alumno() {       // Constructor global
    }

    public Alumno(int id, String nombre, String apellido) {     // Constructor local
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void mostrarNombre(int id, String nombre, String apellido) {
        System.out.println("Hola, soy el estudiante " + id + " y me llamo " + nombre + " " + apellido);
    }

}
