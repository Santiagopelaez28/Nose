package org.example;

public class Usuario {
    int id;
    String nombre;
    String correo;
    String Contraseña;
    String metodoPago;

    public void cambiarContraseña(){

    }
}
