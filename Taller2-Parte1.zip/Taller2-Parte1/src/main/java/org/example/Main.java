// Taller 2 - Parte 1

package org.example;

/**
 *
 * @author Cristian Hernandez Muñoz - David Santiago Peláez Forero - Niver Emiro Vides Daza
 */

public class Main {
    public static void main(String[] args) {

    }
}
